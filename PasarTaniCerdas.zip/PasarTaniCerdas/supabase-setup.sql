-- =====================================================================
-- PASAR TANI CERDAS  -  skema database Supabase
-- Jalankan SEKALI di project Supabase BARU:  SQL Editor > New query >
-- tempel seluruh isi file ini > Run.
-- Aman dijalankan di project kosong. JANGAN dijalankan di project kasir.
-- =====================================================================

-- ---------- tanggal "hari ini" zona WITA (Palu) ----------
create or replace function public.today_wita() returns date
language sql stable as $$ select (now() at time zone 'Asia/Makassar')::date $$;

create or replace function public._rp(n bigint) returns text
language sql immutable as $$ select 'Rp ' || replace(to_char(coalesce(n, 0), 'FM999,999,999,999,990'), ',', '.') $$;

-- =====================================================================
-- TABEL
-- =====================================================================
create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  name        text not null default '',
  phone       text not null default '',      -- privat: hanya lewat fungsi my_profile / contact_phone
  city        text not null default '',
  address     text not null default '',      -- privat
  seller_type text check (seller_type in ('petani', 'pedagang', 'tengkulak')),
  store       text,
  verified    boolean not null default false,
  is_admin    boolean not null default false,
  lat         double precision,
  lng         double precision,
  rating      numeric(2,1) not null default 0,
  rc          integer not null default 0,
  created_at  timestamptz not null default now()
);

create table public.products (
  id         uuid primary key default gen_random_uuid(),
  seller     uuid not null references public.profiles(id) on delete cascade,
  name       text not null check (char_length(name) between 2 and 120),
  cat        text not null check (cat in ('hasil-panen','buah','beras-palawija','benih','pupuk','pestisida','alat-mesin')),
  price      bigint not null check (price > 0),
  unit       text not null default 'pcs' check (char_length(unit) between 1 and 30),
  stock      integer not null default 0 check (stock >= 0),
  min_order  integer not null default 1 check (min_order >= 1),
  grade      text not null default '' check (char_length(grade) <= 40),
  descr      text not null default '' check (char_length(descr) <= 4000),
  img        text not null default '',
  sold       integer not null default 0,
  rating     numeric(2,1) not null default 0,
  rc         integer not null default 0,
  created_at timestamptz not null default now()
);
create index products_cat_idx on public.products (cat, sold desc);
create index products_seller_idx on public.products (seller, created_at desc);

create table public.harvests (
  id         uuid primary key default gen_random_uuid(),
  farmer     uuid not null references public.profiles(id) on delete cascade,
  commodity  text not null,
  qty        integer not null check (qty > 0),
  min_price  bigint not null check (min_price > 0),
  grade      text not null default 'A',
  location   text not null,
  hdate      date,
  deadline   date not null,
  descr      text not null default '',
  status     text not null default 'open' check (status in ('open', 'closed')),
  best       bigint not null default 0,
  count      integer not null default 0,
  lat        double precision,
  lng        double precision,
  created_at timestamptz not null default now()
);
create index harvests_status_idx on public.harvests (status, created_at desc);

create table public.offers (
  id         uuid primary key default gen_random_uuid(),
  harvest    uuid not null references public.harvests(id) on delete cascade,
  bidder     uuid not null references public.profiles(id) on delete cascade,
  price      bigint not null check (price > 0),
  qty        integer not null check (qty > 0),
  note       text not null default '',
  status     text not null default 'pending' check (status in ('pending', 'accepted', 'rejected')),
  created_at timestamptz not null default now()
);
create index offers_harvest_idx on public.offers (harvest, price desc);

create table public.conversations (
  id         uuid primary key default gen_random_uuid(),
  a          uuid not null references public.profiles(id) on delete cascade,
  b          uuid not null references public.profiles(id) on delete cascade,
  product    uuid references public.products(id) on delete set null,
  pname      text not null default '',
  last       text not null default '',
  unread_a   integer not null default 0,
  unread_b   integer not null default 0,
  updated_at timestamptz not null default now(),
  constraint conv_order check (a < b),
  constraint conv_unique unique (a, b)
);
create index conversations_b_idx on public.conversations (b);

create table public.deals (
  id         uuid primary key default gen_random_uuid(),
  code       text not null,
  conv       uuid not null references public.conversations(id) on delete cascade,
  seller     uuid not null references public.profiles(id) on delete cascade,
  buyer      uuid not null references public.profiles(id) on delete cascade,
  product    uuid references public.products(id) on delete set null,
  harvest    uuid references public.harvests(id) on delete set null,
  name       text not null,
  unit       text not null,
  cat        text not null default 'hasil-panen',
  img        text not null default '',
  qty        integer not null check (qty > 0),
  price      bigint not null check (price > 0),
  method     text not null check (method in ('ambil', 'antar', 'cod', 'ekspedisi')),
  note       text not null default '',
  status     text not null default 'ditawarkan' check (status in ('ditawarkan', 'disepakati', 'selesai', 'ditolak', 'dibatalkan')),
  reviewed   boolean not null default false,
  created_at timestamptz not null default now(),
  agreed_at  timestamptz,
  done_at    timestamptz
);
create index deals_conv_idx on public.deals (conv);
create index deals_seller_idx on public.deals (seller, created_at desc);
create index deals_buyer_idx on public.deals (buyer, created_at desc);

create table public.messages (
  id         uuid primary key default gen_random_uuid(),
  conv       uuid not null references public.conversations(id) on delete cascade,
  sender     uuid references public.profiles(id) on delete set null,
  body       text not null default '',
  offer      bigint,
  deal       uuid references public.deals(id) on delete cascade,
  sys        boolean not null default false,
  created_at timestamptz not null default now()
);
create index messages_conv_idx on public.messages (conv, created_at desc);

create table public.reviews (
  id         uuid primary key default gen_random_uuid(),
  deal       uuid not null unique references public.deals(id) on delete cascade,
  product    uuid references public.products(id) on delete set null,
  seller     uuid not null references public.profiles(id) on delete cascade,
  buyer      uuid references public.profiles(id) on delete set null,
  name       text not null default '',
  rating     integer not null check (rating between 1 and 5),
  comment    text not null default '' check (char_length(comment) <= 1000),
  created_at timestamptz not null default now()
);
create index reviews_product_idx on public.reviews (product, created_at desc);
create index reviews_seller_idx on public.reviews (seller, created_at desc);

create table public.notifications (
  id         uuid primary key default gen_random_uuid(),
  uid        uuid not null references public.profiles(id) on delete cascade,
  title      text not null,
  body       text not null default '',
  link       text not null default '',
  phone      text not null default '',
  read       boolean not null default false,
  created_at timestamptz not null default now()
);
create index notifications_uid_idx on public.notifications (uid, created_at desc);

create table public.commodities (
  id         uuid primary key default gen_random_uuid(),
  name       text not null,
  unit       text not null default 'kg',
  price      bigint not null check (price > 0),
  chg        numeric(6,1) not null default 0,
  updated_at timestamptz not null default now()
);
create table public.commodity_history (
  commodity uuid not null references public.commodities(id) on delete cascade,
  d         date not null,
  price     bigint not null check (price > 0),
  primary key (commodity, d)
);

-- =====================================================================
-- PROFIL OTOMATIS SAAT DAFTAR
-- =====================================================================
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, name, phone, city)
  values (new.id,
          coalesce(nullif(trim(new.raw_user_meta_data->>'name'), ''), split_part(new.email, '@', 1)),
          coalesce(trim(new.raw_user_meta_data->>'phone'), ''),
          coalesce(trim(new.raw_user_meta_data->>'city'), ''));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- =====================================================================
-- HAK AKSES (Row Level Security + hak per kolom)
-- Semua perubahan penting (chat, kesepakatan, stok, ulasan, lelang)
-- HANYA lewat fungsi di bawah, jadi tidak bisa diakali dari browser.
-- =====================================================================
alter table public.profiles          enable row level security;
alter table public.products          enable row level security;
alter table public.harvests          enable row level security;
alter table public.offers            enable row level security;
alter table public.conversations     enable row level security;
alter table public.deals             enable row level security;
alter table public.messages          enable row level security;
alter table public.reviews           enable row level security;
alter table public.notifications     enable row level security;
alter table public.commodities       enable row level security;
alter table public.commodity_history enable row level security;

revoke all on public.profiles, public.products, public.harvests, public.offers, public.conversations, public.deals,
              public.messages, public.reviews, public.notifications, public.commodities, public.commodity_history
  from anon, authenticated;

-- profil: publik kecuali no. HP & alamat
grant select (id, name, city, seller_type, store, verified, is_admin, lat, lng, rating, rc, created_at) on public.profiles to anon, authenticated;
grant update (name, city, address, phone, lat, lng) on public.profiles to authenticated;
create policy profiles_read on public.profiles for select using (true);
create policy profiles_update_own on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- produk: semua bisa lihat; penjual kelola produknya sendiri (angka terjual & rating tidak bisa diubah)
grant select on public.products to anon, authenticated;
grant insert (seller, name, cat, price, unit, stock, min_order, grade, descr, img) on public.products to authenticated;
grant update (name, cat, price, unit, stock, min_order, grade, descr, img) on public.products to authenticated;
grant delete on public.products to authenticated;
create policy products_read on public.products for select using (true);
create policy products_insert_own on public.products for insert to authenticated
  with check (seller = auth.uid() and exists (select 1 from public.profiles p where p.id = auth.uid() and p.seller_type is not null));
create policy products_update_own on public.products for update to authenticated using (seller = auth.uid()) with check (seller = auth.uid());
create policy products_delete_own on public.products for delete to authenticated using (seller = auth.uid());

grant select on public.harvests to anon, authenticated;
create policy harvests_read on public.harvests for select using (true);

grant select on public.offers to authenticated;
create policy offers_read_own on public.offers for select to authenticated
  using (bidder = auth.uid() or exists (select 1 from public.harvests h where h.id = harvest and h.farmer = auth.uid()));

grant select on public.conversations to authenticated;
create policy conversations_member on public.conversations for select to authenticated using (auth.uid() in (a, b));

grant select on public.deals to authenticated;
create policy deals_party on public.deals for select to authenticated using (auth.uid() in (seller, buyer));

grant select on public.messages to authenticated;
create policy messages_member on public.messages for select to authenticated
  using (exists (select 1 from public.conversations c where c.id = conv and auth.uid() in (c.a, c.b)));

grant select on public.reviews to anon, authenticated;
create policy reviews_read on public.reviews for select using (true);

grant select on public.notifications to authenticated;
create policy notifications_own on public.notifications for select to authenticated using (uid = auth.uid());

grant select on public.commodities, public.commodity_history to anon, authenticated;
create policy commodities_read on public.commodities for select using (true);
create policy history_read on public.commodity_history for select using (true);

-- =====================================================================
-- FUNGSI BANTU (internal, tidak bisa dipanggil dari browser)
-- =====================================================================
create or replace function public._notify(p_uid uuid, p_title text, p_body text, p_link text, p_phone text default '')
returns void language sql security definer set search_path = public as $$
  insert into public.notifications (uid, title, body, link, phone)
  select p_uid, p_title, coalesce(p_body, ''), coalesce(p_link, ''), coalesce(p_phone, '') where p_uid is not null;
$$;

create or replace function public._sys(p_conv uuid, p_text text)
returns void language sql security definer set search_path = public as $$
  insert into public.messages (conv, sender, body, sys) values (p_conv, null, p_text, true);
  update public.conversations set last = left(p_text, 140), updated_at = now() where id = p_conv;
$$;

create or replace function public._me() returns uuid
language plpgsql stable security definer set search_path = public as $$
declare v uuid := auth.uid();
begin
  if v is null then raise exception 'Silakan masuk terlebih dahulu'; end if;
  return v;
end $$;

revoke execute on function public._notify(uuid, text, text, text, text) from public, anon, authenticated;
revoke execute on function public._sys(uuid, text) from public, anon, authenticated;
revoke execute on function public._me() from public, anon, authenticated;
revoke execute on function public.handle_new_user() from public, anon, authenticated;

-- =====================================================================
-- FUNGSI YANG DIPANGGIL APLIKASI
-- =====================================================================

-- profil sendiri lengkap (termasuk no. HP & alamat)
create or replace function public.my_profile() returns setof public.profiles
language sql stable security definer set search_path = public as $$
  select * from public.profiles where id = auth.uid();
$$;

-- no. WA orang lain: hanya jika dia penjual, atau kalian sudah pernah chat
create or replace function public.contact_phone(p_user uuid) returns text
language sql stable security definer set search_path = public as $$
  select case when auth.uid() is null then ''
              when p.seller_type is not null
                or exists (select 1 from public.conversations c
                           where (c.a = auth.uid() and c.b = p.id) or (c.b = auth.uid() and c.a = p.id))
              then p.phone else '' end
  from public.profiles p where p.id = p_user;
$$;

-- "Mulai jualan" (dipanggil lagi untuk mengubah nama/jenis toko)
create or replace function public.become_seller(p_type text, p_store text, p_phone text, p_city text)
returns void language plpgsql security definer set search_path = public as $$
declare v_me uuid := public._me(); v_was text;
begin
  if p_type is null or p_type not in ('petani', 'pedagang', 'tengkulak') then raise exception 'Pilih jenis penjual'; end if;
  if char_length(trim(coalesce(p_store, ''))) < 3 then raise exception 'Nama toko minimal 3 huruf'; end if;
  if char_length(trim(p_store)) > 60 then raise exception 'Nama toko maksimal 60 huruf'; end if;
  if char_length(regexp_replace(coalesce(p_phone, ''), '\D', '', 'g')) < 9 then
    raise exception 'Isi nomor WhatsApp yang aktif, pembeli akan menghubungi lewat nomor ini'; end if;
  if trim(coalesce(p_city, '')) = '' then raise exception 'Isi kota atau kabupaten'; end if;
  select seller_type into v_was from public.profiles where id = v_me;
  update public.profiles set seller_type = p_type, store = trim(p_store), phone = trim(p_phone), city = trim(p_city) where id = v_me;
  if v_was is null then
    perform public._notify(p.id, 'Penjual baru mendaftar', trim(p_store) || ' dari ' || trim(p_city) || ' menunggu verifikasi', '#/toko/' || v_me)
    from public.profiles p where p.is_admin;
  end if;
end $$;

create or replace function public.start_chat(p_other uuid, p_product uuid default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_me uuid := public._me(); v_id uuid; v_pname text; v_pid uuid;
begin
  if p_other is null or p_other = v_me then raise exception 'Tidak bisa chat dengan diri sendiri'; end if;
  if not exists (select 1 from public.profiles where id = p_other) then raise exception 'Pengguna tidak ditemukan'; end if;
  if p_product is not null then select id, name into v_pid, v_pname from public.products where id = p_product; end if;
  insert into public.conversations as cv (a, b, product, pname)
  values (least(v_me, p_other), greatest(v_me, p_other), v_pid, coalesce(v_pname, ''))
  on conflict (a, b) do update
    set product = coalesce(excluded.product, cv.product),
        pname   = case when excluded.product is not null then excluded.pname else cv.pname end
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.send_message(p_conv uuid, p_body text, p_offer bigint default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_me uuid := public._me(); c public.conversations; v_body text := trim(coalesce(p_body, '')); v_offer bigint := p_offer;
begin
  select * into c from public.conversations where id = p_conv;
  if not found or v_me not in (c.a, c.b) then raise exception 'Percakapan tidak ditemukan'; end if;
  if v_offer is not null and v_offer <= 0 then v_offer := null; end if;
  if v_body = '' and v_offer is null then raise exception 'Pesan masih kosong'; end if;
  if char_length(v_body) > 2000 then raise exception 'Pesan terlalu panjang (maks. 2000 huruf)'; end if;
  insert into public.messages (conv, sender, body, offer) values (p_conv, v_me, v_body, v_offer);
  update public.conversations
     set last = case when v_body <> '' then left(v_body, 140) else 'Tawaran harga ' || public._rp(v_offer) end,
         updated_at = now(),
         unread_a = unread_a + case when v_me = c.b then 1 else 0 end,
         unread_b = unread_b + case when v_me = c.a then 1 else 0 end
   where id = p_conv;
end $$;

create or replace function public.read_conv(p_conv uuid) returns void
language plpgsql security definer set search_path = public as $$
declare v_me uuid := public._me();
begin
  update public.conversations
     set unread_a = case when a = v_me then 0 else unread_a end,
         unread_b = case when b = v_me then 0 else unread_b end
   where id = p_conv and v_me in (a, b);
end $$;

-- penjual mengirim kartu kesepakatan ke chat
create or replace function public.create_deal(p_conv uuid, p_product uuid, p_name text, p_unit text, p_qty integer,
                                              p_price bigint, p_method text, p_note text, p_harvest uuid default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_me uuid := public._me(); c public.conversations; v_buyer uuid; p public.products;
        v_name text := trim(coalesce(p_name, '')); v_unit text := coalesce(nullif(trim(p_unit), ''), 'pcs');
        v_cat text := 'hasil-panen'; v_img text := ''; v_id uuid; v_store text;
begin
  select * into c from public.conversations where id = p_conv;
  if not found or v_me not in (c.a, c.b) then raise exception 'Percakapan tidak ditemukan'; end if;
  if not exists (select 1 from public.profiles where id = v_me and seller_type is not null) then
    raise exception 'Hanya penjual yang bisa membuat kartu kesepakatan'; end if;
  v_buyer := case when c.a = v_me then c.b else c.a end;
  if p_product is not null then
    select * into p from public.products where id = p_product;
    if not found or p.seller <> v_me then raise exception 'Produk tidak ditemukan di toko Anda'; end if;
    if coalesce(p_qty, 0) > p.stock then raise exception 'Stok % tinggal % %', p.name, p.stock, p.unit; end if;
    v_name := p.name; v_unit := p.unit; v_cat := p.cat; v_img := p.img;
  end if;
  if char_length(v_name) < 2 then raise exception 'Isi nama barang'; end if;
  if coalesce(p_qty, 0) < 1 then raise exception 'Isi jumlah barang'; end if;
  if coalesce(p_price, 0) < 1 then raise exception 'Isi harga kesepakatan per satuan'; end if;
  if p_method is null or p_method not in ('ambil', 'antar', 'cod', 'ekspedisi') then raise exception 'Pilih cara ambil atau kirim'; end if;
  insert into public.deals (code, conv, seller, buyer, product, harvest, name, unit, cat, img, qty, price, method, note)
  values ('KS-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6)), p_conv, v_me, v_buyer,
          case when p_product is not null then p.id end, p_harvest, v_name, v_unit, v_cat, v_img, p_qty, p_price, p_method,
          left(trim(coalesce(p_note, '')), 300))
  returning id into v_id;
  insert into public.messages (conv, sender, deal) values (p_conv, v_me, v_id);
  update public.conversations
     set last = 'Kartu kesepakatan ' || v_name, updated_at = now(),
         unread_a = unread_a + case when v_buyer = c.a then 1 else 0 end,
         unread_b = unread_b + case when v_buyer = c.b then 1 else 0 end
   where id = p_conv;
  select coalesce(store, name) into v_store from public.profiles where id = v_me;
  perform public._notify(v_buyer, 'Kartu kesepakatan baru',
    v_store || ': ' || v_name || ' ' || p_qty || ' ' || v_unit || ', total ' || public._rp(p_qty * p_price) || '. Buka chat untuk menyetujui.',
    '#/chat/' || p_conv);
  return v_id;
end $$;

-- setuju / tolak / batal / terima
create or replace function public.deal_action(p_deal uuid, p_act text) returns void
language plpgsql security definer set search_path = public as $$
declare v_me uuid := public._me(); d public.deals; v_other uuid; v_name text; v_phone text; v_total text; v_link text;
begin
  select * into d from public.deals where id = p_deal for update;
  if not found or v_me not in (d.seller, d.buyer) then raise exception 'Kesepakatan tidak ditemukan'; end if;
  select name, phone into v_name, v_phone from public.profiles where id = v_me;
  v_other := case when v_me = d.buyer then d.seller else d.buyer end;
  v_total := public._rp(d.qty * d.price);
  v_link  := '#/chat/' || d.conv;

  if p_act = 'setuju' then
    if v_me <> d.buyer or d.status <> 'ditawarkan' then raise exception 'Kesepakatan ini tidak bisa disetujui lagi'; end if;
    if d.product is not null then
      update public.products set stock = stock - d.qty, sold = sold + d.qty where id = d.product and stock >= d.qty;
      if not found then raise exception 'Stok tidak cukup atau produk sudah dihapus. Minta penjual membuat kartu baru'; end if;
    end if;
    update public.deals set status = 'disepakati', agreed_at = now() where id = p_deal;
    perform public._sys(d.conv, v_name || ' menyetujui kesepakatan ' || d.code || ': ' || d.name || ' ' || d.qty || ' ' || d.unit || ', ' || v_total || '.');
    perform public._notify(v_other, 'Kesepakatan ' || d.code || ' disetujui', v_name || ' setuju ' || d.name || ', ' || v_total || '.', v_link, v_phone);

  elsif p_act = 'tolak' then
    if v_me <> d.buyer or d.status <> 'ditawarkan' then raise exception 'Kesepakatan ini tidak bisa ditolak lagi'; end if;
    update public.deals set status = 'ditolak' where id = p_deal;
    perform public._sys(d.conv, v_name || ' menolak kartu kesepakatan ' || d.code || '.');
    perform public._notify(v_other, 'Kesepakatan ' || d.code || ' ditolak', v_name || ' belum setuju. Lanjutkan diskusi di chat.', v_link);

  elsif p_act = 'batal' then
    if d.status not in ('ditawarkan', 'disepakati') then raise exception 'Kesepakatan ini sudah tidak bisa dibatalkan'; end if;
    if d.status = 'ditawarkan' and v_me = d.buyer then raise exception 'Pembeli cukup menekan Tolak'; end if;
    if d.status = 'disepakati' and d.product is not null then
      update public.products set stock = stock + d.qty, sold = greatest(0, sold - d.qty) where id = d.product;
    end if;
    update public.deals set status = 'dibatalkan' where id = p_deal;
    perform public._sys(d.conv, v_name || ' membatalkan kesepakatan ' || d.code || '.');
    perform public._notify(v_other, 'Kesepakatan ' || d.code || ' dibatalkan', 'Dibatalkan oleh ' || v_name || '.', v_link);

  elsif p_act = 'terima' then
    if v_me <> d.buyer or d.status <> 'disepakati' then raise exception 'Hanya pembeli yang bisa menandai barang sudah diterima'; end if;
    update public.deals set status = 'selesai', done_at = now() where id = p_deal;
    perform public._sys(d.conv, v_name || ' menandai barang sudah diterima. Transaksi ' || d.code || ' selesai.');
    perform public._notify(v_other, 'Transaksi ' || d.code || ' selesai', v_name || ' sudah menerima ' || d.name || '.', v_link);
  else
    raise exception 'Aksi tidak dikenal';
  end if;
end $$;

-- ulasan hanya dari pembeli yang transaksinya selesai
create or replace function public.add_review(p_deal uuid, p_rating integer, p_comment text) returns void
language plpgsql security definer set search_path = public as $$
declare v_me uuid := public._me(); d public.deals; v_name text;
begin
  select * into d from public.deals where id = p_deal for update;
  if not found or d.buyer <> v_me then raise exception 'Hanya pembeli dari transaksi ini yang bisa memberi ulasan'; end if;
  if d.status <> 'selesai' then raise exception 'Ulasan bisa diberikan setelah barang diterima'; end if;
  if d.reviewed then raise exception 'Transaksi ini sudah diulas'; end if;
  if p_rating is null or p_rating not between 1 and 5 then raise exception 'Pilih 1 sampai 5 bintang'; end if;
  select name into v_name from public.profiles where id = v_me;
  insert into public.reviews (deal, product, seller, buyer, name, rating, comment)
  values (d.id, d.product, d.seller, v_me, v_name, p_rating, left(trim(coalesce(p_comment, '')), 1000));
  update public.deals set reviewed = true where id = d.id;
  if d.product is not null then
    update public.products
       set rating = coalesce((select round(avg(r.rating)::numeric, 1) from public.reviews r where r.product = d.product), 0),
           rc     = (select count(*) from public.reviews r where r.product = d.product)
     where id = d.product;
  end if;
  update public.profiles
     set rating = coalesce((select round(avg(r.rating)::numeric, 1) from public.reviews r where r.seller = d.seller), 0),
         rc     = (select count(*) from public.reviews r where r.seller = d.seller)
   where id = d.seller;
  perform public._notify(d.seller, 'Ulasan baru ' || p_rating || ' bintang', v_name || ': ' || left(coalesce(p_comment, ''), 100), '#/toko/' || d.seller);
end $$;

-- ---------- lelang ----------
create or replace function public.close_expired() returns void
language sql security definer set search_path = public as $$
  update public.harvests set status = 'closed' where status = 'open' and deadline < public.today_wita();
$$;

create or replace function public.create_harvest(p_commodity text, p_qty integer, p_min bigint, p_grade text, p_location text,
                                                 p_hdate date, p_deadline date, p_descr text) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_me uuid := public._me(); pr public.profiles; v_id uuid;
begin
  select * into pr from public.profiles where id = v_me;
  if pr.seller_type is null then raise exception 'Mulai jualan dulu sebelum memasang panen'; end if;
  if char_length(trim(coalesce(p_commodity, ''))) < 2 then raise exception 'Isi nama komoditas'; end if;
  if coalesce(p_qty, 0) < 1 or coalesce(p_min, 0) < 1 then raise exception 'Isi jumlah dan harga minimal'; end if;
  if char_length(trim(coalesce(p_location, ''))) < 2 then raise exception 'Isi lokasi lahan'; end if;
  if p_deadline is null or p_deadline < public.today_wita() then raise exception 'Tanggal tutup lelang tidak boleh sebelum hari ini'; end if;
  insert into public.harvests (farmer, commodity, qty, min_price, grade, location, hdate, deadline, descr, lat, lng)
  values (v_me, trim(p_commodity), p_qty, p_min, coalesce(nullif(trim(p_grade), ''), 'A'), trim(p_location), p_hdate, p_deadline,
          left(trim(coalesce(p_descr, '')), 2000), pr.lat, pr.lng)
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.make_offer(p_harvest uuid, p_price bigint, p_qty integer, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare v_me uuid := public._me(); h public.harvests; v_name text; v_phone text;
begin
  perform public.close_expired();
  select * into h from public.harvests where id = p_harvest for update;
  if not found or h.status <> 'open' then raise exception 'Lelang sudah ditutup'; end if;
  if h.farmer = v_me then raise exception 'Tidak bisa menawar panen sendiri'; end if;
  if coalesce(p_price, 0) < h.min_price then raise exception 'Harga minimal %/kg', public._rp(h.min_price); end if;
  if coalesce(p_qty, 0) < 1 or p_qty > h.qty then raise exception 'Jumlah harus antara 1 dan % kg', h.qty; end if;
  insert into public.offers (harvest, bidder, price, qty, note) values (p_harvest, v_me, p_price, p_qty, left(trim(coalesce(p_note, '')), 300));
  update public.harvests set count = count + 1, best = greatest(best, p_price) where id = p_harvest;
  select name, phone into v_name, v_phone from public.profiles where id = v_me;
  perform public._notify(h.farmer, 'Tawaran baru: ' || h.commodity, v_name || ' menawar ' || public._rp(p_price) || '/kg untuk ' || p_qty || ' kg',
                         '#/lelang/' || p_harvest, v_phone);
end $$;

-- daftar tawaran: penawar lain disamarkan kecuali untuk pemilik panen
create or replace function public.harvest_offers(p_harvest uuid)
returns table (id uuid, bidder_name text, price bigint, qty integer, note text, status text, mine boolean, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select o.id,
         case when h.farmer = auth.uid() or o.bidder = auth.uid() then p.name else 'Penawar lain' end,
         o.price, o.qty,
         case when h.farmer = auth.uid() or o.bidder = auth.uid() then o.note else '' end,
         o.status, coalesce(o.bidder = auth.uid(), false), o.created_at
  from public.offers o join public.harvests h on h.id = o.harvest join public.profiles p on p.id = o.bidder
  where o.harvest = p_harvest
  order by o.price desc, o.created_at;
$$;

-- terima tawaran = lelang ditutup + chat dibuka + kartu kesepakatan dikirim ke pemenang
create or replace function public.decide_offer(p_offer uuid, p_accept boolean) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_me uuid := public._me(); o public.offers; h public.harvests; v_conv uuid; v_name text;
begin
  select * into o from public.offers where id = p_offer for update;
  if not found then raise exception 'Penawaran tidak ditemukan'; end if;
  select * into h from public.harvests where id = o.harvest for update;
  if h.farmer <> v_me then raise exception 'Penawaran tidak ditemukan'; end if;
  if o.status <> 'pending' or h.status <> 'open' then raise exception 'Penawaran sudah diputuskan'; end if;
  if not p_accept then
    update public.offers set status = 'rejected' where id = p_offer;
    perform public._notify(o.bidder, 'Tawaran ditolak: ' || h.commodity,
      'Tawaran ' || public._rp(o.price) || '/kg belum diterima. Anda bisa menawar lagi selama lelang dibuka.', '#/lelang/' || h.id);
    return null;
  end if;
  update public.harvests set status = 'closed' where id = h.id;
  update public.offers set status = 'accepted' where id = p_offer;
  perform public._notify(x.bidder, 'Lelang ' || h.commodity || ' ditutup', 'Petani memilih tawaran lain. Terima kasih sudah menawar.', '#/lelang/' || h.id)
  from (select distinct bidder from public.offers where harvest = h.id and id <> p_offer and status = 'pending' and bidder <> o.bidder) x;
  update public.offers set status = 'rejected' where harvest = h.id and id <> p_offer and status = 'pending';
  v_conv := public.start_chat(o.bidder, null);
  update public.conversations set pname = 'Lelang ' || h.commodity where id = v_conv;
  select name into v_name from public.profiles where id = v_me;
  perform public._sys(v_conv, v_name || ' menerima tawaran lelang ' || h.commodity || ': ' || public._rp(o.price) || '/kg untuk ' || o.qty || ' kg.');
  perform public.create_deal(v_conv, null, h.commodity || ' (lelang, grade ' || h.grade || ')', 'kg', o.qty, o.price, 'ambil',
                             'Lokasi lahan: ' || h.location || '. ' || o.note, h.id);
  return v_conv;
end $$;

-- ---------- notifikasi ----------
create or replace function public.mark_notifs_read() returns void
language sql security definer set search_path = public as $$
  update public.notifications set read = true where uid = auth.uid() and not read;
$$;

-- ---------- khusus admin ----------
create or replace function public._admin() returns uuid
language plpgsql stable security definer set search_path = public as $$
declare v uuid := public._me();
begin
  if not exists (select 1 from public.profiles where id = v and is_admin) then raise exception 'Khusus admin'; end if;
  return v;
end $$;
revoke execute on function public._admin() from public, anon, authenticated;

create or replace function public.admin_verify(p_user uuid, p_val boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._admin();
  update public.profiles set verified = p_val where id = p_user and seller_type is not null;
  if not found then raise exception 'Toko tidak ditemukan'; end if;
  perform public._notify(p_user, case when p_val then 'Toko Anda terverifikasi' else 'Verifikasi toko dicabut' end,
    case when p_val then 'Tanda Terverifikasi sekarang tampil di toko Anda.' else 'Hubungi admin untuk info lebih lanjut.' end, '#/toko/' || p_user);
end $$;

create or replace function public.admin_delete_product(p_product uuid) returns void
language plpgsql security definer set search_path = public as $$
declare p public.products;
begin
  perform public._admin();
  delete from public.products where id = p_product returning * into p;
  if p.id is not null then
    perform public._notify(p.seller, 'Produk dihapus admin', p.name || ' dihapus karena melanggar aturan jualan.', '#/jualan');
  end if;
end $$;

create or replace function public.admin_add_commodity(p_name text, p_unit text, p_price bigint) returns void
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  perform public._admin();
  if char_length(trim(coalesce(p_name, ''))) < 2 or coalesce(p_price, 0) < 1 then raise exception 'Isi nama komoditas dan harga'; end if;
  insert into public.commodities (name, unit, price) values (trim(p_name), coalesce(nullif(trim(p_unit), ''), 'kg'), p_price) returning id into v_id;
  insert into public.commodity_history (commodity, d, price) values (v_id, public.today_wita(), p_price);
end $$;

create or replace function public.admin_set_price(p_commodity uuid, p_price bigint) returns void
language plpgsql security definer set search_path = public as $$
declare v_prev bigint;
begin
  perform public._admin();
  if coalesce(p_price, 0) < 1 then raise exception 'Harga tidak valid'; end if;
  if not exists (select 1 from public.commodities where id = p_commodity) then raise exception 'Komoditas tidak ditemukan'; end if;
  insert into public.commodity_history (commodity, d, price) values (p_commodity, public.today_wita(), p_price)
  on conflict (commodity, d) do update set price = excluded.price;
  select price into v_prev from public.commodity_history where commodity = p_commodity and d < public.today_wita() order by d desc limit 1;
  update public.commodities
     set price = p_price, updated_at = now(),
         chg = case when v_prev is null or v_prev = 0 then 0 else round(((p_price - v_prev)::numeric / v_prev) * 100, 1) end
   where id = p_commodity;
end $$;

create or replace function public.admin_delete_commodity(p_commodity uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._admin();
  delete from public.commodities where id = p_commodity;
end $$;

-- =====================================================================
-- REALTIME (chat & notifikasi langsung muncul tanpa refresh)
-- =====================================================================
alter publication supabase_realtime add table public.messages, public.notifications, public.conversations, public.deals;

-- =====================================================================
-- PENYIMPANAN FOTO PRODUK
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('foto', 'foto', true, 2097152, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do nothing;

create policy "foto: upload ke folder sendiri" on storage.objects for insert to authenticated
  with check (bucket_id = 'foto' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "foto: hapus milik sendiri" on storage.objects for delete to authenticated
  using (bucket_id = 'foto' and (storage.foldername(name))[1] = auth.uid()::text);

-- SELESAI. Langkah berikutnya ada di PANDUAN-SETUP.txt
